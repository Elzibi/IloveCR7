# checkstyle

## 一、checkstyle的介绍

### 1、简介

 Checkstyle是一款检查java程序代码样式的静态分析工具，可以有效的帮助我们检视代码以便更好的遵循代码编写标准，特别适用于小组开发时彼此间的样式规范和统一。Checkstyle提供了高可配置性，以便适用于各种代码规范。 

### 2、检验的主要内容

·注解——Annotations

·阻止检查——Block Checks

·类设计——Class Design

·编码——Coding

·标头——Headers

·导入顺序——Imports

·Javadoc注释——Javadoc Comments

·指标——Metrics

·杂——Metrics

·修饰符——Miscellaneous

·命名约定——Modifiers

·正则表达式——Regexp

·尺寸违规——Size Violations

·空格——Whitespace

### 3、相关语法

checkstyle配置是通过指定modules来应用到java文件的。modules是树状结构，以一个名为Checker的module作为root结点，一般的Checker都会包括TreeWalker子module。在xml配置文件中通过module的name属性来区分module，module的properties可以控制如何去执行这个module，每个property都有一个默认值，所有的check都有一个severity属性，用它来指定check的level。TreeWalker为每个java文件创建一个语法树，在结点之间调用submodules的Checks。

checkstyle相关具体语法规则说明如下所示：

![1607442914667](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607442914667.png)

相关内容的具体使用可参见官方文档：https://checkstyle.sourceforge.io/

## 二、checkstyle的安装

1、在idea中安装checkstyle插件

![1607440620745](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607440620745.png)

![1607440851161](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607440851161.png)

![1607440905724](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607440905724.png)

下载安装完成后点击restart即可

![1607441323363](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607441323363.png)

重新启动idea后看到其有下方有checkstyle插件的显示，则表明其已经安装完成，相关截图如下所示：

![1607441710556](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607441710556.png)

查看checkstyle是否已经被启用

![1607442012703](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607442012703.png)

## 三、配置checkstyle

#### （一）配置过程

1、引入相关的checkstyle的配置文件

![1607443334858](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443334858.png)

2、点击添加配置文件后所进行的相关操作如下所示：

![1607443544805](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443544805.png)

3、添加本地配置文件相关的具体过程如下：

![1607443663586](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443663586.png)

4、出现如下相关的截图信息则表明已经配置完成

![1607443729356](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443729356.png)

![1607443897421](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443897421.png)

![1607443974543](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607443974543.png)

#### （二）配置过程中所遇到的问题

1、在添加本地配置规则时为添加文件描述

![1607444103679](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607444103679.png)

2、checkstyle的版本更新，导致出现不兼容的情况

![1607444421357](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607444421357.png)

3、配置文件缺少DOCTYPE module PUBLIC等相关的配置信息。

![1607444522056](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607444522056.png)

![1607444700715](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607444700715.png)

4、相关的module未放在名为TreeWalker中，将checker下的module放置到名为TreeWalker的module中即可。

![1607444772355](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607444772355.png)

## 四、checkstyle的使用

1、使用相关的配置文件扫描项目：

![1607445060113](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607445060113.png)

2、以扫描整个项目进行相关的讲解。点击检查整个项目的java代码规范后相关的运行结果如下所示：

![1607445293808](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607445293808.png)

3、点击相关的报错详情即可跳转到相关的具体报错位置。然后根据相关的具体位置进行修改即可。

![1607491126708](D:/大三/大三上学期/软件工程—期末作品/技术分享/checkstyle/image/1607491126708.png)